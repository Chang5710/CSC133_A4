package com.mycompany.a4.game.gameWorld.gameObject.moveAbleObject;

public interface ISteerable {
	public void turnLeft();
	public void turnRight();
}
